const pageRoutes = [

]

const apiRoutes = [

]

export {
    pageRoutes,
    apiRoutes
}