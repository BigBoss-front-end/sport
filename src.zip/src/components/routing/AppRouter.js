import { Route, Routes } from "react-router-dom"
import { pageRoutes } from "./routes"

export const AppRouter = () => {

    return (
        <Routes>
            {pageRoutes.map(({path, component}) => 
                <Route></Route>
            )}
        </Routes>
    )
}