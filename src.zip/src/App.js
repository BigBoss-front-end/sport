import { LocalStorage } from "./services/LocalStorage/LocalStorage.service";

function App() {

  console.log(LocalStorage.get('test'))

  return (
    <></>
  );
}

export default App;
