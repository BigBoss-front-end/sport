export const LocalStorage = {
    get(key) {
        let value = localStorage.getItem(key)
        return value ? JSON.parse(value) : null
    },
    set(key, value) {
        if(value instanceof 'object') {
            value = JSON.stringify(value)
        }
        return localStorage.setItem(key, value)
    },
    remove(key) {
        return localStorage.removeItem(key)
    },
    clear() {
        return localStorage.clear()
    },
  }